#!/bin/bash -x

export PATH="/opt/venv/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/snap/bin"

# 24小时重启一次
task_pid=`ps aux | grep "[/]opt/venv/bin/python -c from task import main" | awk '{print $2}'`
if [[ $task_pid != "" ]];then
    etimes=`ps -o etimes= -p $task_pid`
    if [[ $etimes -gt 86400 ]];then
        supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart agent
        supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart task        
    fi
fi

if [[ ! -f /tmp/task_last_execute.time ]]; then
    exit 0
fi

last_time=`cat /tmp/task_last_execute.time`
now_time=`date +%s`

num=$((now_time - last_time))
abs_num=$((num < 0 ? -1 * num : num))

if [[ $abs_num -gt 180 ]]; then
    pass_time=2000

    if [[ -f /tmp/monitor_restart.time ]];then
        restart_time=`cat /tmp/monitor_restart.time`
        pass_time=$((now_time - restart_time))
    fi

    pass_time=$((pass_time < 0 ? -1 * pass_time : pass_time))

    # 半小时最多重启一次
    if [[ $pass_time -gt 1800 ]]; then
        supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart task
        echo $now_time > /tmp/monitor_restart.time
    fi
    
fi
