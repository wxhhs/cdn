from distutils.core import setup
from Cython.Build import cythonize
 
setup(
  name = 'Hello world app',
  ext_modules = cythonize("gen_clickimg.py", compiler_directives={'always_allow_keywords': True}),
)

