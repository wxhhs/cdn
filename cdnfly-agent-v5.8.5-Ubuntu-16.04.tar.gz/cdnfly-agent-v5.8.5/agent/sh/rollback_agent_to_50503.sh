#!/bin/bash 

if [[ ! -d /opt/cdnfly-50503-bak ]];then
    echo "未发现cdnfly-50503-bak目录"
    exit 1
fi

if [[ ! -d /usr/local/openresty-50503-bak ]];then
    echo "未发现openresty-50503-bak目录"
    exit 1
fi

# 恢复agent
rm -rf /opt/cdnfly/
\cp -a /opt/cdnfly-50503-bak /opt/cdnfly/ 

# 恢复openresty
ps aux | grep [n]ginx | awk '{print $2}' | xargs kill || true
sleep 2
ps aux | grep [n]ginx | awk '{print $2}' | xargs kill -9 || true
sleep 2
rm -f /var/run/nginx.sock
rm -rf /usr/local/openresty/
\cp -a  /usr/local/openresty-50503-bak /usr/local/openresty
ulimit -n 51200 && /usr/local/openresty/nginx/sbin/nginx || true

rm -f /tmp/agent_upgrade_*.done 

supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf reload
echo "恢复完成！"
