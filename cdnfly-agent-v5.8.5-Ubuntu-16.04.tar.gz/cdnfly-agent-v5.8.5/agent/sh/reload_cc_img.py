# -*- coding: utf-8 -*-

import random
import os
import sys


sys.path.append("/opt/cdnfly/agent/")
from util import set_dict

def load_captcha():
    captcha_dir = "/opt/cdnfly/nginx/conf/captcha"
    captcha_dict = []
    
    print("start loading captcha img...")
    captcha_list = []
    
    for filename in os.listdir(captcha_dir):
        if filename.endswith('.png'):
            captcha = os.path.splitext(filename)[0]
            captcha_list.append(captcha)
    
    for i, captcha in enumerate(captcha_list):
        key = "captcha{0}".format(i + 1)
        value = captcha
        captcha_dict.append({"key":key,"value":value,"dict":"dict_captcha"})
    
    
    set_dict(captcha_dict)
    print("loading captcha img done.")



def load_clickimg():
    click_dir = "/opt/cdnfly/nginx/conf/click"
    click_dict = []
    

    print("start loading click img...")
    click_list = []
    
    for filename in os.listdir(click_dir):
        if filename.endswith('.jpg'):
            click = os.path.splitext(filename)[0]
            click_list.append(click)
    
    for i, click in enumerate(click_list):
        key = "click{0}".format(i + 1)
        value = click
        click_dict.append({"key":key,"value":value,"dict":"dict_captcha"})
    
    set_dict(click_dict)
    print("loading click img done.")

def load_clickimg_easy():
    click_dir = "/opt/cdnfly/nginx/conf/click-easy"
    click_dict = []
    

    print("start loading click img easy...")
    click_list = []
    
    for filename in os.listdir(click_dir):
        if filename.endswith('.jpg'):
            click = os.path.splitext(filename)[0]
            click_list.append(click)
    
    for i, click in enumerate(click_list):
        key = "easy_click{0}".format(i + 1)
        value = click
        click_dict.append({"key":key,"value":value,"dict":"dict_captcha"})
    
    set_dict(click_dict)
    print("loading click img easy done.")


def load_rotateimg():
    rotate_dir = "/opt/cdnfly/nginx/conf/rotate"
    rotate_dict = []
    
    print("start loading rotate img...")
    rotate_list = []
    
    for filename in os.listdir(rotate_dir):
        if filename.endswith('.png'):
            rotate = os.path.splitext(filename)[0]
            rotate_list.append(rotate)
    
    for i, rotate in enumerate(rotate_list):
        key = "rotate{0}".format(i + 1)
        value = rotate
        rotate_dict.append({"key":key,"value":value,"dict":"dict_captcha"})
    
    set_dict(rotate_dict)
    print("loading rotate img done.")


def load_slideimg():
    slide_dir = "/opt/cdnfly/nginx/conf/slide"
    slide_dict = []
    
    print("start loading slide img...")
    slide_list = []
    
    for filename in os.listdir(slide_dir):
        if filename.endswith('.png'):
            slide = os.path.splitext(filename)[0]
            slide_list.append(slide)
    
    for i, slide in enumerate(slide_list):
        key = "slide{0}".format(i + 1)
        value = slide
        slide_dict.append({"key":key,"value":value,"dict":"dict_captcha"})
        
    set_dict(slide_dict)
    print("loading slide img done.")

def load_slideimg_easy():
    slide_dir = "/opt/cdnfly/nginx/conf/slide-easy"
    slide_dict = []
    
    print("start loading slide img easy...")
    slide_list = []
    
    for filename in os.listdir(slide_dir):
        if filename.endswith('.png'):
            slide = os.path.splitext(filename)[0]
            slide_list.append(slide)
    
    for i, slide in enumerate(slide_list):
        key = "easy_slide{0}".format(i + 1)
        value = slide
        slide_dict.append({"key":key,"value":value,"dict":"dict_captcha"})
        
    set_dict(slide_dict)
    print("loading slide img easy done.")

load_captcha()
load_clickimg()
load_rotateimg()
load_slideimg()
load_clickimg_easy()
load_slideimg_easy()