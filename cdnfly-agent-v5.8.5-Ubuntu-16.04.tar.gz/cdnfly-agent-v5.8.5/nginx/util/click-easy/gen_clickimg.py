#coding=utf-8
from __future__ import division
from PIL import Image, ImageDraw, ImageFont
from fontTools.ttLib import TTFont
import random
import os
import sys
import multiprocessing
from multiprocessing import Pool
import shutil

# 目录定义
base_dir = "/opt/cc-img"
tmp_dir = os.path.join(base_dir, "click-easy-tmp")
final_dir = os.path.join(base_dir, "click-easy")

def print_flush(message):
    """封装print和flush操作"""
    print(message)
    sys.stdout.flush()

def extract_chinese_characters(font_path):
    font = TTFont(font_path)
    chinese_characters = []
    for table in font['cmap'].tables:
        for char_code in table.cmap:
            if 0x4E00 <= char_code <= 0x9FFF:
                chinese_characters.append(unichr(char_code))
    return chinese_characters

def random_chinese_characters_from_font(font_path, num_chars):
    chinese_characters = extract_chinese_characters(font_path)
    return random.sample(chinese_characters, min(num_chars, len(chinese_characters)))

def no_overlap(draw, text, font, img_width, img_height, existing_boxes):
    max_attempts = 50
    for _ in range(max_attempts):
        x = random.randint(0, img_width - 50)
        y = random.randint(0, img_height - 50)
        new_box = (x, y, x + 50, y + 50)

        overlapping = any(
            new_box[0] < box[2] and new_box[2] > box[0] and
            new_box[1] < box[3] and new_box[3] > box[1]
            for box in existing_boxes
        )
        if not overlapping:
            return x, y
    return None, None

def draw_text_on_image(image_path, font_path, num_chars):
    text_list = random_chinese_characters_from_font(font_path, num_chars)
    img = Image.open(image_path)
    draw = ImageDraw.Draw(img)
    font = ImageFont.truetype(font_path, 40)

    img_width, img_height = img.size
    existing_boxes = []
    
    word_xy = []
    words = ""
    for text in text_list:
        words += text
        x, y = no_overlap(draw, text, font, img_width, img_height, existing_boxes)
        if x is not None and y is not None:
            angle = random.randint(-30, 30)
            text_image = Image.new('RGBA', (50,50), (255, 255, 255, 0))
            text_draw = ImageDraw.Draw(text_image)
            text_draw.text((0,0), text, font=font, fill=(255, 215, 0))
            rotated_text_image = text_image.rotate(angle, expand=1)
            img.paste(rotated_text_image, (x, y), rotated_text_image)

            existing_boxes.append((x, y, x + 50, y + 50))
        else:
            print_flush("Skipping text %s due to lack of space." % text.encode('utf-8'))
            return

        word_xy.append(str(x)+"x"+str(y))

    # 创建透明画布用于底部文字
    bottom_height = 50  # 底部画布高度
    bottom_canvas = Image.new('RGBA', (img_width, bottom_height), (255, 255, 255, 0))
    bottom_draw = ImageDraw.Draw(bottom_canvas)
    
    # 在底部画布上写文字
    text_width = 0
    bottom_font = ImageFont.truetype(font_path, 30)
    for i, text in enumerate(text_list):
        width, height = font.getsize(text)
        text_width += width
        if i < len(text_list) - 1:
            text_width += 10  # 字符间距

    # 计算起始x坐标，使文字居中
    start_x = (img_width - text_width) // 2
    current_x = start_x
    
    for text in text_list:
        # 为每个字符创建单独的旋转文字图层
        width, height = bottom_font.getsize(text)
        char_img = Image.new('RGBA', (width + 20, height + 20), (255, 255, 255, 0))  # 增加padding防止旋转时裁切
        char_draw = ImageDraw.Draw(char_img)
        char_draw.text((10, 10), text, font=bottom_font, fill=(0, 0, 0))  # 改为黑色(0,0,0)
        
        # 随机旋转
        angle = random.randint(-30, 30)
        rotated_char = char_img.rotate(angle, expand=1)
        
        # 计算垂直居中的y坐标
        char_y = (bottom_height - rotated_char.size[1]) // 2
        
        # 粘贴到底部画布
        bottom_canvas.paste(rotated_char, (current_x, char_y), rotated_char)
        current_x += width  - 5  # 加上字符间距

    # 创建新的合并图片
    new_img = Image.new('RGB', (img_width, img_height + bottom_height), (255, 255, 255))
    new_img.paste(img, (0, 0))
    new_img.paste(bottom_canvas, (0, img_height), bottom_canvas)

    # 保存图片
    output_path = os.path.join(tmp_dir, "一一一-"+"-".join(word_xy) + ".jpg")
    new_img.save(output_path)


def process_chunk(args):
    """处理单个进程的任务"""
    start_index, end_index, image_paths, font_path, num_chars = args
    for i in range(start_index, end_index):
        if i % 100 == 0:
            progress = (i * 100.0) / end_index
            print_flush("进程 %s - 已生成 %d 张图片，完成 %.1f%%" % (
                multiprocessing.current_process().name, i, progress))
            
        image_path = random.choice(image_paths)
        draw_text_on_image(image_path, font_path, num_chars)

def get_process_count(mode):
    """根据mode获取进程数"""
    cpu_count = multiprocessing.cpu_count()
    if mode == 'full':
        return cpu_count
    elif mode == 'half':
        return max(1, cpu_count // 2)
    else:
        return 1

def setup_directories():
    """准备目录"""
    if os.path.exists(tmp_dir):
        shutil.rmtree(tmp_dir)
    os.makedirs(tmp_dir)

def switch_directories():
    """切换目录"""
    if os.path.exists(final_dir):
        shutil.rmtree(final_dir)
    os.rename(tmp_dir, final_dir)

def main(mode='full'):
    # 图片文件路径列表
    image_paths = ['1.jpg', '2.jpg', '3.jpg', '4.jpg', '5.jpg']
    font_path = 'taobaomaicaiti.otf'
    num_images = 2000
    num_chars = 3

    setup_directories()
    
    process_count = get_process_count(mode)
    print_flush("使用 %d 个进程生成图片..." % process_count)
    
    # 计算每个进程需要处理的图片数量
    chunk_size = num_images // process_count
    chunks = []
    
    # 创建任务分块
    for i in range(process_count):
        start = i * chunk_size
        end = start + chunk_size if i < process_count - 1 else num_images
        chunks.append((start, end, image_paths, font_path, num_chars))
    
    # 创建进程池并执行任务
    pool = Pool(process_count)
    pool.map(process_chunk, chunks)
    pool.close()
    pool.join()
    
    print_flush("完成！共生成%d张图片" % num_images)
    
    # 切换目录
    switch_directories()
    print_flush("目录切换完成")


if __name__ == '__main__':
    mode = sys.argv[1] if len(sys.argv) > 1 else 'full'
    main(mode)