#!/bin/bash -x

set -o errexit

download(){
  local url1=$1
  local url2=$2
  local filename=$3

  speed1=`curl -m 5 -L -s -w '%{speed_download}' "$url1" -o /dev/null || true`
  speed1=${speed1%%.*}
  speed2=`curl -m 5 -L -s -w '%{speed_download}' "$url2" -o /dev/null || true`
  speed2=${speed2%%.*}
  echo "speed1:"$speed1
  echo "speed2:"$speed2
  url="$url1\n$url2"
  if [[ $speed2 -gt $speed1 ]]; then
    url="$url2\n$url1"
  fi
  echo -e $url | while read l;do
    echo "using url:"$l
    wget --dns-timeout=5 --connect-timeout=5 --read-timeout=10 --tries=2 "$l" -O $filename && break
  done
  
}

update() {
    cd /opt/cdnfly/nginx/conf
    type=$1
    url=$2
    if [[ $type == "system" ]];then
        download "https://dl2.lotcdn.com/cdnfly/cc-img-20250228.tar.xz" "https://us.lotcdn.com/cdnfly/cc-img-20250228.tar.xz" "cc-img.tar.xz"
    else
        wget --dns-timeout=5 --connect-timeout=5 --read-timeout=10 --tries=2 "$url" -O cc-img.tar.xz
    fi

    if `xz -t cc-img.tar.xz`;then 
        rm -rf captcha click rotate slide slide-easy click-easy
        tar xf cc-img.tar.xz
        rm -f cc-img.tar.xz

        # reload
        cd /opt/cdnfly/agent/sh
        /opt/venv/bin/python reload_cc_img.py
        # 更新时间戳
        date +%s > "$TIMESTAMP_FILE"
    fi
}

url_type=$1
cc_img_url=$2
at_hour=$3

TIMESTAMP_FILE="/opt/.last_run_update_cc_img"

# 如果时间戳文件不存在，创建它
if [ ! -f "$TIMESTAMP_FILE" ]; then
    date +%s > "$TIMESTAMP_FILE"
    exit 0
fi

# 读取上次运行时间
last_run=$(cat "$TIMESTAMP_FILE")
current_time=$(date +%s)
elapsed_time=$((current_time - last_run))
current_hour=$(date +%k)

run_at_hour=3
if [[ $url_type == "custom" ]];then
    run_at_hour=$at_hour
fi

next_hour=$((run_at_hour+1))

# 如果last_run为1000，表示人工触发，则立即执行
if [ $last_run == "1000" ]; then
    update "$url_type" "$cc_img_url"
    exit 0
fi

# 如果距离上次更新时间小于22小时，则不执行
if [ $elapsed_time -ge 79200 ]; then
    # 如果运行时间在指定时间，20%的概率执行
    if [ $run_at_hour -eq $current_hour ]; then
        if [[ $((RANDOM % 5)) -eq 0 ]]; then
            # 执行主脚本
            update "$url_type" "$cc_img_url"
        fi
    # 如果运行时间在指定时间的下一个小时，则立即执行
    elif [ $next_hour -eq $current_hour ]; then
        update "$url_type" "$cc_img_url"
    fi
fi
