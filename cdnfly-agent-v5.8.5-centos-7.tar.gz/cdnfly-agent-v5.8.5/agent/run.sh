cd /opt/cdnfly/agent
/opt/venv/bin/python route.py