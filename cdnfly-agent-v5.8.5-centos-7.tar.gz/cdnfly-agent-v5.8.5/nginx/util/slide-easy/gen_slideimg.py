# -*- coding: utf-8 -*-

import multiprocessing
from multiprocessing import Pool
import threading
from PIL import Image, ImageDraw
import random
import math
import os
import subprocess
import sys
import shutil

# 倍数
scale_factor = 4

# 半圆点数
num_segments = 180*2

# 计算半圆的半径
square_size = 40*scale_factor
radius = square_size // 6

def random_slide(start_x, start_y):
    functions = [s1, s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,s20,s21,s22,s23,s24 ]
    random_func = random.choice(functions)
    return random_func(start_x, start_y)

# 左凸圆
def left_convex(start_x, start_y, path):
    center_x = start_x
    center_y = start_y + square_size/2

    for i in range(num_segments + 1):
        angle = math.pi/2 + (i / float(num_segments)) * math.pi  # 从90度到270度
        x = center_x + radius * math.cos(angle)
        y = center_y - radius * math.sin(angle)
        path.append((x, y))

    return path


# 右凸圆
def right_convex(start_x, start_y, path):
    center_x = start_x + square_size
    center_y = start_y + square_size/2

    for i in range(num_segments + 1):
        angle = math.pi/2 + (i / float(num_segments)) * math.pi  # 从90度到270度
        x = center_x - radius * math.cos(angle)  # 加负号使圆弧向右
        y = center_y + radius * math.sin(angle)  
        path.append((x, y))

    return path

# 上凸圆
def up_convex(start_x, start_y, path):
    center_x = start_x + square_size // 2
    center_y = start_y

    for i in range(num_segments + 1):
        angle = (i / float(num_segments)) * math.pi  # 从0度到180度
        x = center_x + radius * math.cos(angle)
        y = center_y - radius * math.sin(angle)  # 加负号使圆弧向上
        path.append((x, y))
    return path

# 下凸圆
def down_convex(start_x, start_y, path):
    center_x = start_x + square_size // 2
    center_y = start_y + square_size

    for i in range(num_segments + 1):
        angle = math.pi - (i / float(num_segments)) * math.pi  # 从180度到0度
        x = center_x + radius * math.cos(angle)
        y = center_y + radius * math.sin(angle)  # 去掉负号使圆弧向下
        path.append((x, y))

    return path

# 左凹圆
def left_concave(start_x, start_y, path):
    center_x = start_x 
    center_y = start_y + square_size // 2

    for i in range(num_segments + 1):
        angle = math.pi/2 + (i / float(num_segments)) * math.pi  # 从90度到270度
        x = center_x - radius * math.cos(angle)
        y = center_y - radius * math.sin(angle)
        path.append((x, y))

    return path

# 右凹圆
def right_concave(start_x, start_y, path):
    center_x = start_x + square_size
    center_y = start_y + square_size/2

    for i in range(num_segments + 1):
        angle = math.pi/2 + (i / float(num_segments)) * math.pi  # 从90度到270度
        x = center_x + radius * math.cos(angle)
        y = center_y + radius * math.sin(angle)
        path.append((x, y))

    return path

# 上凹圆
def up_concave(start_x, start_y, path):
    center_x = start_x + square_size // 2
    center_y = start_y

    for i in range(num_segments + 1):
        angle = (i / float(num_segments)) * math.pi  # 从0度到180度
        x = center_x + radius * math.cos(angle)
        y = center_y + radius * math.sin(angle)  # 加负号使圆弧向下
        path.append((x, y))

    return path

# 下凹圆
def down_concave(start_x, start_y, path):
    center_x = start_x + square_size // 2
    center_y = start_y + square_size

    for i in range(num_segments + 1):
        angle = math.pi - (i / float(num_segments)) * math.pi  # 从180度到0度
        x = center_x + radius * math.cos(angle)
        y = center_y - radius * math.sin(angle)  # 保持负号使圆弧向上
        path.append((x, y))

    return path

# 上凸右凸
def s1(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左下角
    path.append((start_x, start_y+square_size))

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
    # 右凸圆
    path =  right_convex(start_x, start_y, path)

    # 右上角
    path.append((start_x+square_size, start_y))

    # 上凸圆
    path = up_convex(start_x, start_y, path)

    return path

# 上凸右凹
def s2(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左下角
    path.append((start_x, start_y+square_size))

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
    # 右凹
    path =  right_concave(start_x, start_y, path)

    # 右上角
    path.append((start_x+square_size, start_y))

    # 上凸
    path = up_convex(start_x, start_y, path)

    return path

# 上凹右凸
def s3(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左下角
    path.append((start_x, start_y+square_size))

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
    # 右凸
    path =  right_convex(start_x, start_y, path)

    # 右上角
    path.append((start_x+square_size, start_y))

    # 上凹
    path = up_concave(start_x, start_y, path)

    return path

# 上凹右凹
def s4(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左下角
    path.append((start_x, start_y+square_size))

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
    # 右凹
    path =  right_concave(start_x, start_y, path)

    # 右上角
    path.append((start_x+square_size, start_y))

    # 上凹
    path = up_concave(start_x, start_y, path)

    return path

# 上凹右凹
def s4(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左下角
    path.append((start_x, start_y+square_size))

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
    # 右凹
    path =  right_concave(start_x, start_y, path)

    # 右上角
    path.append((start_x+square_size, start_y))

    # 上凹
    path = up_concave(start_x, start_y, path)

    return path

# 上凸下凸
def s5(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左下角
    path.append((start_x, start_y+square_size))

    # 下凸
    path =  down_convex(start_x, start_y, path)

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
     # 右上角
    path.append((start_x+square_size, start_y))

    # 上凸
    path =  up_convex(start_x, start_y, path)

    return path

# 上凸下凹
def s6(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左下角
    path.append((start_x, start_y+square_size))

    # 下凹
    path =  down_concave(start_x, start_y, path)

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
     # 右上角
    path.append((start_x+square_size, start_y))

    # 上凸
    path =  up_convex(start_x, start_y, path)

    return path


# 上凹下凸
def s7(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左下角
    path.append((start_x, start_y+square_size))

    # 下凸
    path =  down_convex(start_x, start_y, path)

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
     # 右上角
    path.append((start_x+square_size, start_y))

    # 上凹
    path =  up_concave(start_x, start_y, path)

    return path

# 上凹下凹
def s8(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左下角
    path.append((start_x, start_y+square_size))

    # 下凹
    path =  down_concave(start_x, start_y, path)

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
     # 右上角
    path.append((start_x+square_size, start_y))

    # 上凹
    path =  up_concave(start_x, start_y, path)

    return path

# 上凸左凸
def s9(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左凸
    path =  left_convex(start_x, start_y, path)

    # 左下角
    path.append((start_x, start_y+square_size))

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
     # 右上角
    path.append((start_x+square_size, start_y))

    # 上凸
    path =  up_convex(start_x, start_y, path)

    return path

# 上凸左凹
def s10(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左凹
    path =  left_concave(start_x, start_y, path)

    # 左下角
    path.append((start_x, start_y+square_size))

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
     # 右上角
    path.append((start_x+square_size, start_y))

    # 上凸
    path =  up_convex(start_x, start_y, path)

    return path

# 上凹左凸
def s11(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左凸
    path =  left_convex(start_x, start_y, path)

    # 左下角
    path.append((start_x, start_y+square_size))

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
     # 右上角
    path.append((start_x+square_size, start_y))

    # 上凹
    path =  up_concave(start_x, start_y, path)

    return path

# 上凹左凹
def s12(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左凹
    path =  left_concave(start_x, start_y, path)

    # 左下角
    path.append((start_x, start_y+square_size))

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
     # 右上角
    path.append((start_x+square_size, start_y))

    # 上凹
    path =  up_concave(start_x, start_y, path)

    return path

# 右凸下凸
def s13(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左下角
    path.append((start_x, start_y+square_size))

    # 下凸
    path =  down_convex(start_x, start_y, path)

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
    # 右凸
    path =  right_convex(start_x, start_y, path)

     # 右上角
    path.append((start_x+square_size, start_y))

    return path


# 右凸下凹
def s14(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左下角
    path.append((start_x, start_y+square_size))

    # 下凹
    path =  down_concave(start_x, start_y, path)

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
    # 右凸
    path =  right_convex(start_x, start_y, path)

     # 右上角
    path.append((start_x+square_size, start_y))

    return path

# 右凹下凸
def s15(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左下角
    path.append((start_x, start_y+square_size))

    # 下凸
    path =  down_convex(start_x, start_y, path)

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
    # 右凹
    path =  right_concave(start_x, start_y, path)

     # 右上角
    path.append((start_x+square_size, start_y))

    return path

# 右凹下凹
def s16(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左下角
    path.append((start_x, start_y+square_size))

    # 下凹
    path =  down_concave(start_x, start_y, path)

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
    # 右凹
    path =  right_concave(start_x, start_y, path)

     # 右上角
    path.append((start_x+square_size, start_y))

    return path

# 右凸左凸
def s17(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左凸
    path =  left_convex(start_x, start_y, path)

    # 左下角
    path.append((start_x, start_y+square_size))

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
    # 右凸
    path =  right_convex(start_x, start_y, path)

     # 右上角
    path.append((start_x+square_size, start_y))

    return path

# 右凸左凹
def s18(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左凹
    path =  left_concave(start_x, start_y, path)

    # 左下角
    path.append((start_x, start_y+square_size))

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
    # 右凸
    path =  right_convex(start_x, start_y, path)

     # 右上角
    path.append((start_x+square_size, start_y))

    return path

# 右凹左凸
def s19(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左凸
    path =  left_convex(start_x, start_y, path)

    # 左下角
    path.append((start_x, start_y+square_size))

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
    # 右凹
    path =  right_concave(start_x, start_y, path)

     # 右上角
    path.append((start_x+square_size, start_y))

    return path

# 右凹左凹
def s20(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左凹
    path =  left_concave(start_x, start_y, path)

    # 左下角
    path.append((start_x, start_y+square_size))

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
    # 右凹
    path =  right_concave(start_x, start_y, path)

     # 右上角
    path.append((start_x+square_size, start_y))

    return path

# 下凸左凸
def s21(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左凸
    path =  left_convex(start_x, start_y, path)

    # 左下角
    path.append((start_x, start_y+square_size))

    # 下凸
    path =  down_convex(start_x, start_y, path)

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
     # 右上角
    path.append((start_x+square_size, start_y))

    return path

# 下凸左凹
def s22(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左凹
    path =  left_concave(start_x, start_y, path)

    # 左下角
    path.append((start_x, start_y+square_size))

    # 下凸
    path =  down_convex(start_x, start_y, path)

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
     # 右上角
    path.append((start_x+square_size, start_y))

    return path


# 下凹左凸
def s23(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左凸
    path =  left_convex(start_x, start_y, path)

    # 左下角
    path.append((start_x, start_y+square_size))

    # 下凹
    path =  down_concave(start_x, start_y, path)

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
     # 右上角
    path.append((start_x+square_size, start_y))

    return path

# 下凹左凹
def s24(start_x,start_y):
    # 定义路径点,逆时针
    path = []
    
    # 左上角
    path.append((start_x, start_y))

    # 左凹
    path =  left_concave(start_x, start_y, path)

    # 左下角
    path.append((start_x, start_y+square_size))

    # 下凹
    path =  down_concave(start_x, start_y, path)

    # 右下角
    path.append((start_x+square_size, start_y+square_size))
    
     # 右上角
    path.append((start_x+square_size, start_y))

    return path

def overlay(width, height):
    # img1是用来遮罩原图(含填充)， img2是用来原图上画线， img3是用paste来裁剪用

    # 创建一个8倍大的透明图层来实现超取样
    large_size = (width * scale_factor, height * scale_factor)
    img1 = Image.new('RGBA', large_size, (255, 255, 255, 0))
    draw = ImageDraw.Draw(img1)

    # 绘画的实体40x40,从左上角为起点，x范围100至(width-50), y范围10至height-50
    start_x = random.randint(100, width  - 50 ) * scale_factor
    start_y = random.randint(10, height - 50) * scale_factor
    path = random_slide(start_x, start_y)

    # 绘制填充形状
    fill_color = (0, 0, 0, 150)  # 黑色填充，透明度一半
    draw.polygon(path, fill=fill_color)
    
    # 添加白色边框效果
    line_color = (255, 255, 255, 255)
    draw.line(path + [path[0]], fill=line_color, width=scale_factor)
    
    # 缩放回原始大小
    img1 = img1.resize((width, height), Image.ANTIALIAS)

    img2 = Image.new('RGBA', large_size, (255, 255, 255, 0))
    draw = ImageDraw.Draw(img2)
    draw.line(path + [path[0]], fill=line_color, width=2*scale_factor)
    img2 = img2.resize((width, height), Image.LANCZOS)

    img3 = Image.new('L', (width, height), 0)
    draw = ImageDraw.Draw(img3)
    scaled_points = [(int(x / scale_factor), int(y / scale_factor)) for x, y in path]
    draw.polygon(scaled_points, fill=255)

    return img1,img2,img3,path


def ensure_dir(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)

def process_single_image(args):
    try:
        i, j, image_path = args
        main_img = Image.open("/data/sh/util/slide-easy/" + image_path)
        width, height = main_img.size
        img1, img2, img3, path = overlay(width, height)

        origin_img = main_img.convert('RGBA')
        result1 = Image.alpha_composite(origin_img, img1)
        result2 = Image.alpha_composite(origin_img, img2)

        start_x = path[0][0] / scale_factor
        start_y = path[0][1] / scale_factor
        min_x = start_x - 7
        min_y = start_y -7
        max_x = start_x + square_size / scale_factor + 7
        max_y = start_y + square_size / scale_factor + 7
        cropped_result = result2.crop((min_x, min_y, max_x, max_y))
        cropped_mask = img3.crop((min_x, min_y, max_x, max_y))

        triangle_img = Image.new('RGBA', cropped_result.size, (255, 255, 255, 0))
        triangle_img.paste(cropped_result, mask=cropped_mask)

        final_width = width + 70
        final_height = max(height, triangle_img.size[1])
        final_img = Image.new('RGBA', (final_width, final_height), (255, 255, 255, 0))
        final_img.paste(result1, (0, 0))
        
        triangle_x = width + 5
        triangle_y = (final_height - 54) // 2
        final_img.paste(triangle_img, (triangle_x, triangle_y), triangle_img)

        output_filename = '{2}x{3}-{0}{1}.png'.format(
            i, j, 
            int(path[0][0]/scale_factor) -7, 
            int(path[0][1]/scale_factor) -7
        )
        final_img.save(img_dir + output_filename, 'PNG', optimize=True, quality=85)
        
        return "Processed " + output_filename
    
    except Exception as e:
        return "Error processing image {0}: {1}".format(image_path, str(e))

def compress_png_files():
    # 获取当前目录中所有的 PNG 文件
    os.chdir(img_dir)
    files = [f for f in os.listdir('.') if f.endswith('.png')]

    # 遍历文件列表
    for file in files:
        # 构建 pngquant 命令
        command = [
            '/usr/local/bin/pngquant',          # pngquant 命令的路径，根据需要进行调整
            '--quality=30',        # 设置质量为 30
            '--speed', '8',        # 设置速度为 8
            '--force',             # 强制覆盖现有文件
            '--ext', '.png',       # 输出文件扩展名，用于覆盖原文件
            '--', file             # 确保 pngquant 处理文件名中可能包含的特殊字符
        ]
        
        # 执行命令
        subprocess.call(command)

def safe_print(message):
    """Thread-safe print function with automatic flush"""
    print(message)
    sys.stdout.flush()

def get_process_count(mode):
    """Calculate process count based on mode and CPU cores"""
    cpu_count = multiprocessing.cpu_count()
    
    if mode == 'full':
        return cpu_count
    elif mode == 'half':
        return max(1, cpu_count // 2)
    else:
        return 1  # Default fallback

def ensure_clean_dir(directory):
    """Ensure directory exists and is empty"""
    if os.path.exists(directory):
        shutil.rmtree(directory)
    os.makedirs(directory)

def swap_directories(tmp_dir, final_dir):
    """Safely swap temporary and final directories"""
    if os.path.exists(final_dir):
        shutil.rmtree(final_dir)
    os.rename(tmp_dir, final_dir)

def main(mode='full'):
    # Define directories
    base_dir = "/opt/cc-img"
    tmp_dir = os.path.join(base_dir, "slide-easy-tmp")
    final_dir = os.path.join(base_dir, "slide-easy")
    
    # Ensure clean temporary directory
    ensure_clean_dir(tmp_dir)
    
    # Update global img_dir to use temporary directory
    global img_dir
    img_dir = tmp_dir + "/"
    
    # Calculate process count
    process_count = get_process_count(mode)
    safe_print("Starting processing with {0} processes...".format(process_count))
    
    # Prepare tasks list
    tasks = []
    for i in range(1, 11):
        image_path = str(i) + ".jpg"
        for j in range(200):
            tasks.append((i, j, image_path))

    # Progress tracking
    total = len(tasks)
    processed = 0

    # Create process pool and process images
    pool = Pool(processes=process_count)
    
    try:
        # Process images in chunks to show progress
        results = []
        for result in pool.imap_unordered(process_single_image, tasks):
            processed += 1
            if processed % 10 == 0:
                safe_print("Progress: {0}/{1} ({2:.1f}%)".format(
                    processed,
                    total,
                    (float(processed)/total)*100
                ))
            results.append(result)
    finally:
        pool.close()
        pool.join()

    safe_print("Compressing images...")
    compress_png_files()
    
    # Swap directories
    safe_print("Swapping directories...")
    swap_directories(tmp_dir, final_dir)
    
    safe_print("Processing complete!")

if __name__ == '__main__':
    # You can call main() with 'full' or 'half' mode
    main('full')